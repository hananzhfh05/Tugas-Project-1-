<?php
    include_once 'atas.php';
    include_once 'sidebar.php';
?>
<div class="content-wrapper">
  
<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Praktikum 4</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Layout</a></li>
              <li class="breadcrumb-item active">Fixed Layout</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Nilai Mahasiswa</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
              <?php
class NilaiMahasiswa {
    var $matkul;
    var $nilai;
    var $nim;

    function __construct($matkul,$nilai,$nim){
        $this->nim = $nim;
        $this->matkul = $matkul;
        $this->nilai = $nilai;
    }
    function grade() {
        if ($this->nilai >= 56){
            return 'Lulus';
        }else{
            return 'Tidak Lulus';
        }
    }
    function hasil(){
        if ($this->nilai <= 35) {
            return 'E';
        }elseif ($this->nilai <= 55){
            return 'D';
        }elseif ($this->nilai <= 69){
            return 'C' ;
        }elseif ($this->nilai <= 84){
            return 'B' ;
        }elseif ($this->nilai <= 100){
            return 'A' ;
        }
    }
}

?>
<h1 class="text-center mt-4">Form Nilai Ujian</h1>
<div class="justify-content-around p-3 m-4">
<form class="form-horizontal" method="POST" action="nilai_mahasiswa.php">
  <div class="form-group row">
    <label for="nim" class="col-4 col-form-label">NIM</label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-address-card"></i>
          </div>
        </div> 
        <input id="nim" name="nim" type="text" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="matkul" class="col-4 col-form-label">Mata Kuliah</label> 
    <div class="col-8">
      <select id="matkul" name="matkul" class="custom-select">
        <option value="Dasar Dasar Pemrograman">Dasar Dasar Pemrograman</option>
        <option value="Basis Data">Basis Data</option>
        <option value="Pemrograman Web">Pemrograman Web</option>
      </select>
    </div>
  </div>
  <div class="form-group row">
    <label for="nilai" class="col-4 col-form-label">Nilai</label> 
    <div class="col-8">
      <input id="nilai" name="nilai" type="text" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-primary">Simpan</button>
    </div>
  </div>
</div>
</form>
<?php
    $nim = $_POST['nim'];
    $matkul = $_POST['matkul'];
    $nilai = $_POST['nilai'];
    $data = new NilaiMahasiswa($matkul, $nilai, $nim);

    echo 'NIM : '.$data->nim;
    echo '<br/>Mata Kuliah : '.$data->matkul;
    echo '<br/>Nilai :'.$data->nilai;
    echo "<br/>Hasil : ".$data->hasil();
    echo "<br/>Grade : ". $data->grade();

?>
              </div>
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>

</div>

<div class="content-wrapper">

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Luas & Keliling Persegi Panjang</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
              <?php
require_once "class_persegipanjang.php";

$persegipanjang1 = new persegipanjang(12, 8);
$persegipanjang2 = new persegipanjang(20, 10);

echo "persegi panjang 1 memiliki P = ".$persegipanjang1->panjang. ", L = ".$persegipanjang1->lebar;
echo "<br/> persegi panjang 2 memiliki P = ".$persegipanjang2->panjang. ", L = ".$persegipanjang2->lebar;
echo "<br/> Luas persegi panjang 1 = ".$persegipanjang1->getLuas();
echo "<br/> Luas persegi panjang 2 = ".$persegipanjang2->getLuas();
echo "<br/> keliling persegi panjang 1 = ".$persegipanjang1->getkeliling();
echo "<br/> keliling persegi panjang 2 = ".$persegipanjang2->getkeliling();

?>


</div>


<?php
    include_once 'bawah.php'
?>
