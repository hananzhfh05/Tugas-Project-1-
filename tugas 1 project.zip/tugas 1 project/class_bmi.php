<?php
class BMI{
    public $berat;
    public $tinggi;    

    public function __construct($berat,$tinggi){
        $this->berat = $berat;
        $this->tinggi = $tinggi;
    }

    public function nilai(){
        $cm = $this->tinggi / 100;
        return number_format(($this->berat / ($cm * $cm)),1);
    }

    public function status(){
        if($this->nilai() < 18.5){
            return 'Kekurangan Berat Badan';
        }
        elseif($this->nilai() < 24.9){
            return 'Normal (Ideal)';
        }
        elseif($this->nilai() >= 29.9){
            return 'Kelebihan Berat Badan';
        }
        elseif($this->nilai() >= 30){
            return 'Kegemukan (Obesitas)';
        }
    }

}