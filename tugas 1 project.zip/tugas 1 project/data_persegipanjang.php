<?php
    include_once 'atas.php';
    include_once 'sidebar.php';
?>
<div class="content-wrapper">

<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Fixed Layout</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Layout</a></li>
              <li class="breadcrumb-item active">Fixed Layout</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Title</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
              <?php
require_once "class_persegipanjang.php";

$persegipanjang1 = new persegipanjang(12, 8);
$persegipanjang2 = new persegipanjang(20, 10);

echo "persegi panjang 1 memiliki P = ".$persegipanjang1->panjang. ", L = ".$persegipanjang1->lebar;
echo "<br/> persegi panjang 2 memiliki P = ".$persegipanjang2->panjang. ", L = ".$persegipanjang2->lebar;
echo "<br/> Luas persegi panjang 1 = ".$persegipanjang1->getLuas();
echo "<br/> Luas persegi panjang 2 = ".$persegipanjang2->getLuas();
echo "<br/> keliling persegi panjang 1 = ".$persegipanjang1->getkeliling();
echo "<br/> keliling persegi panjang 2 = ".$persegipanjang2->getkeliling();

?>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                Footer
              </div>
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>

</div>
<?php
    include_once 'bawah.php'
?>