<?php
    include_once 'atas.php';
    include_once 'sidebar.php';
?>
<div class="content-wrapper">

<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Praktikum 2</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Layout</a></li>
              <li class="breadcrumb-item active">Fixed Layout</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Form Belanja</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
<h1 class="text-center mt-4">Belanja Online</h1>
<div class="d-flex justify-content-around p-4">
<form method="POST" action="form_belanja.php">
  <div class="form-group row">
    <label for="customer" class="col-4 col-form-label">Customer</label> 
    <div class="col-8">
      <input id="customer" name="customer" placeholder="Nama Customer" type="text" class="form-control" required="required">
    </div>
  </div>
  <div class="form-group row">
    <label class="col-4">Pilih Produk</label> 
    <div class="col-8">
      <div class="custom-control custom-radio custom-control-inline">
        <input name="produk" id="produk_0" type="radio" class="custom-control-input" value="tv" required="required"> 
        <label for="produk_0" class="custom-control-label">TV</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="produk" id="produk_1" type="radio" class="custom-control-input" value="kulkas" required="required"> 
        <label for="produk_1" class="custom-control-label">KULKAS</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="produk" id="produk_2" type="radio" class="custom-control-input" value="mesin_cuci" required="required"> 
        <label for="produk_2" class="custom-control-label">MESIN CUCI</label>
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="jumlah" class="col-4 col-form-label">Jumlah</label> 
    <div class="col-8">
      <input id="jumlah" name="jumlah" placeholder="Jumlah" type="number" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-success">Kirim</button>
    </div>
  </div>
</form>
<div class="card border-success mb-3" style="max-width: 18rem;">
  <div class="card-header bg-success border-success">Daftar Harga</div>
  <div class="card-body text-success">
    <p class="card-text">TV : 4.200.000</p><hr>
    <p class="card-text">Kulkas : 3.100.000</p><hr>
    <p class="card-text">Mesin Cuci : 3.800.000</p>
  </div>
  <div class="card-footer bg-success border-success">Harga Dapat Berubah Setiap Saat</div>
</div>
</div>
<div class="m-5 border border-dark p-4 rounded">
    <?php
        if(isset($_POST['submit'])){
            $customer = $_POST['customer'];
            $produk = $_POST['produk'];
            $jumlah = $_POST['jumlah'];

            if($produk=='tv'){
                $harga = 4200000;
            }
            elseif($produk=='kulkas'){
                $harga = 3100000;
            }
            elseif($produk=='mesin_cuci'){
                $harga = 3800000;
            }

            $harga_total = $jumlah * $harga;

            switch($produk){
                case "tv": $produk = "TV"; break;
                case "kulkas": $produk = "KULKAS"; break;
                case "mesin_cuci": $produk = "MESIN CUCI"; break;
                default: "";
            }
        }
    ?>
    <?php if(isset($_POST['submit'])){?>
        <p>Nama Customer : <?=$customer?></p>
        <p>Pilih Produk : <?=$produk?></p>
        <p>Jumlah Beli : <?=$jumlah?></p>
        <p>Total Belanja : <?=$harga_total?></p>
        <?php }else{
            echo '<div class="alert alert-success" role="alert">Silahkan Isi Terlebih Dahulu</div>';
    }?>
</div>
<div class="card-body">
<div class="row">
  <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Nilai Mahasiswa</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              
<h1 class="text-center mt-4">Nilai Mahasiswa</h1>
        <div class="d-flex justify-content-around p-4">
            <form method="GET" autocomplete="off" action="form_nilai.php">
                <div class="form-group row">
                    <label for="text" class="col-4 col-form-label" >Nama Lengkap</label> 
                    <div class="col-8">
                    <div class="input-group">
                        <div class="input-group-prepend">
                        <div class="input-group-text">
                            <i class="fa fa-address-book-o"></i>
                        </div>
                        </div> 
                        <input id="text" name="nama" placeholder="Masukan Nama Lengkap Anda" type="text" class="form-control" required="required">
                    </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="select" class="col-4 col-form-label">Mata Kuliah</label> 
                    <div class="col-8">
                    <select id="select" name="matkul" required="required" class="custom-select">
                        <option value="">Pilihlah Mata kuliah</option>
                        <option value="bing">Bahasa Inggris</option>
                        <option value="ppkn">Pendidikan Pancasila dan Kewarganegaraan</option>
                        <option value="ddp">Dasar Dasar Pemrograman</option>
                    </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="text1" class="col-4 col-form-label">Nilai UTS</label> 
                    <div class="col-8">
                    <div class="input-group">
                        <div class="input-group-prepend">
                        <div class="input-group-text">
                            <i class="fa fa-adjust"></i>
                        </div>
                        </div> 
                        <input id="text1" name="uts" placeholder="Masukan Nilai UTS Anda" type="number" class="form-control" required="required">
                    </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="text2" class="col-4 col-form-label">Nilai UAS</label> 
                    <div class="col-8">
                    <div class="input-group">
                        <div class="input-group-prepend">
                        <div class="input-group-text">
                            <i class="fa fa-adjust"></i>
                        </div>
                        </div> 
                        <input id="text2" name="uas" placeholder="Masukan Nilai UAS" type="number" class="form-control" required="required">
                    </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="text3" class="col-4 col-form-label">Nilai Tugas/Praktikum</label> 
                    <div class="col-8">
                    <div class="input-group">
                        <div class="input-group-prepend">
                        <div class="input-group-text">
                            <i class="fa fa-adjust"></i>
                        </div>
                        </div> 
                        <input id="text3" name="tugas" placeholder="Masukan Nilai Tugas/Praktikum" type="number" class="form-control" required="required">
                    </div>
                    </div>
                </div> 
                <div class="form-group row">
                    <div class="offset-4 col-8">
                    <button name="submit" type="submit" class="btn btn-success">Submit</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="d-flex justify-content-around p-4">
                <!-- Cetak php -->
                <?php
                    if(isset($_GET['submit'])){
                        $nama = $_GET['nama'];
                        $matkul = $_GET['matkul'];
                        $nilai_uts = $_GET['uts'];
                        $nilai_uas = $_GET['uas'];
                        $nilai_tugas = $_GET['tugas'];
                        $nilai_akhir = ($nilai_uts + $nilai_uas + $nilai_tugas) / 3;

                        switch($matkul){
                            case "bing": $nama_matkul = "Bahasa Inggris"; break;
                            case "ppkn": $nama_matkul = "Pendidikan Pancasila dan Kewarganegaraan"; break;
                            case "ddp": $nama_matkul = "Dasar Dasar Pemerograman"; break;
                            default: "";
                        }

                    }?>
                
                <?php if(isset($_GET['submit'])){?>
                    <p>Nama Lengkap : <?= $nama?> </p>
                    <p>Mata Kuliah : <?= $nama_matkul?></p> 
                    <p>Nilai UTS : <?= $nilai_uts?></p> 
                    <p>Nilai UAS : <?= $nilai_uas?></p>
                    <p>Nilai Tugas/Praktikum : <?= $nilai_tugas?></p> 
                    <p>Nilai Akhir : <?= $nilai_akhir?></p> 
                <?php }else{
                    echo '<div class="alert alert-success" role="alert"> Silahkan Isi Form Diatas Untuk Menampilkan Nilai , Grade dan Predikat </div>';
                } ?>
                
        </div>
              </div>
      
    

<div class="row">
    <div class="col-12">
        <!-- Default box -->
        <div class="card">
            <div class="card-header">
              <h3 class="card-title">Form Penilaian</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                  <i class="fas fa-minus"></i>
                </button>
                <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
        <div class="card-body">

<h1 class="text-center mt-4">Form Penilaian</h1>
<div class="m-5 border border-success p-4 rounded">
            <form action="form_penilaian.php" method="POST">
                <div class="form-group row">
                    <label for="text" class="col-4 col-form-label" >Nama Lengkap</label> 
                    <div class="col-8">
                    <div class="input-group">
                        <div class="input-group-prepend">
                        <div class="input-group-text">
                            <i class="fa fa-address-book-o"></i>
                        </div>
                        </div> 
                        <input id="text" name="nama" placeholder="Masukan Nama Lengkap Anda" type="text" class="form-control" required="required">
                    </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="select" class="col-4 col-form-label">Mata Kuliah</label> 
                    <div class="col-8">
                    <select id="select" name="matkul" required="required" class="custom-select">
                        <option value="">Pilihlah Mata kuliah</option>
                        <option value="bing">Bahasa Inggris</option>
                        <option value="ppkn">Pendidikan Pancasila dan Kewarganegaraan</option>
                        <option value="ddp">Dasar Dasar Pemrograman</option>
                    </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="text1" class="col-4 col-form-label">Nilai UTS</label> 
                    <div class="col-8">
                    <div class="input-group">
                        <div class="input-group-prepend">
                        <div class="input-group-text">
                            <i class="fa fa-adjust"></i>
                        </div>
                        </div> 
                        <input id="text1" name="uts" placeholder="Masukan Nilai UTS Anda" type="number" class="form-control" required="required">
                    </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="text2" class="col-4 col-form-label">Nilai UAS</label> 
                    <div class="col-8">
                    <div class="input-group">
                        <div class="input-group-prepend">
                        <div class="input-group-text">
                            <i class="fa fa-adjust"></i>
                        </div>
                        </div> 
                        <input id="text2" name="uas" placeholder="Masukan Nilai UAS" type="number" class="form-control" required="required">
                    </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="text3" class="col-4 col-form-label">Nilai Tugas/Praktikum</label> 
                    <div class="col-8">
                    <div class="input-group">
                        <div class="input-group-prepend">
                        <div class="input-group-text">
                            <i class="fa fa-adjust"></i>
                        </div>
                        </div> 
                        <input id="text3" name="tugas" placeholder="Masukan Nilai Tugas/Praktikum" type="number" class="form-control" required="required">
                    </div>
                    </div>
                </div> 
                <div class="form-group row">
                    <div class="offset-4 col-8">
                    <button name="submit" type="submit" class="btn btn-success">Submit</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="m-5 border border-success p-4 rounded">
                <!-- Cetak php -->
                <?php
                include_once ("libfungsi1.php");
                    $nama = $_POST["nama"];
                    $matkul = $_POST["matkul"];
                    $nilai_uts = $_POST["uts"];
                    $nilai_uas = $_POST["uas"];
                    $nilai_tugas = $_POST["tugas"];
                
                      echo"Nama :" . $nama;
                      echo"<br> Mata Kuliah :" . $matkul;
                      echo"<br> Nilai UTS :" . $nilai_uts;
                      echo"<br> Nilai UAS :" . $nilai_uas;
                      echo"<br> Nilai Tugas :" . $nilai_tugas;
                      $total_nilai = ((int)$nilai_uts+(int)$nilai_uas+(int)$nilai_tugas)/3;
                      echo '<br/>Total Nilai : '.$total_nilai;
                      $hasil = kelulusan($total_nilai);
                      echo '<br/>Dinyatakan : '.$hasil;
                      ?>
                
        </div>   

<?php
  include_once 'bawah.php'
?>
