<?php
class Pasien{
    public $id_pasien;
    public $nama;
    public $tmp_lahir;
    public $tgl_lahir;
    public $email;
    public $gender;

    public function __construct($id_pasien,$nama,$tmp_lahir,$tgl_lahir,$email,$gender){
        $this->id_pasien = $id_pasien;
        $this->nama = $nama;
        $this->tmp_lahir = $tmp_lahir;
        $this->tgl_lahir = $tgl_lahir;
        $this->email = $email;
        $this->gender = $gender;
    }
}

