<?php
    include_once 'atas.php';
    include_once 'sidebar.php';
?>
<div class="content-wrapper">
  
<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Kalkulator BMI</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Layout</a></li>
              <li class="breadcrumb-item active">Fixed Layout</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Kalkulator BMI</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">

<div class="m-5 border border-success p-4 rounded">
<form action="form_bmi.php" method="POST">
<div class="form-group row">
    <label for="text" class="col-4 col-form-label" >Nama Lengkap</label> 
    <div class="col-8">
    <div class="input-group">
        <div class="input-group-prepend">
        <div class="input-group-text">
            <i class="fa fa-address-book-o"></i>
        </div>
        </div> 
        <input id="nama" name="nama" placeholder="Masukan Nama Lengkap Anda" type="text" class="form-control" required="required">
    </div>
    </div>
</div>
<div class="form-group row">
    <label for="gender" class="col-4 col-form-label">Gender</label> 
    <div class="col-8">
      <select id="gender" name="gender" class="custom-select">
        <option value="pria">Pria</option>
        <option value="wanita">Wanita</option>
      </select>
    </div>
</div>
<div class="form-group row">
    <label for="text" class="col-4 col-form-label" >Tanggal Periksa</label> 
    <div class="col-8">
    <div class="input-group">
        <div class="input-group-prepend">
        <div class="input-group-text">
            <i class="fa fa-address-book-o"></i>
        </div>
        </div> 
        <input id="tgl_periksa" name="tgl_periksa" placeholder="" type="date" class="form-control" required="required">
    </div>
    </div>
</div>
<div class="form-group row">
    <label for="text1" class="col-4 col-form-label">Berat Badan</label> 
    <div class="col-8">
    <div class="input-group">
        <div class="input-group-prepend">
        <div class="input-group-text">
            <i class="fa fa-adjust"></i>
        </div>
        </div> 
        <input id="bb" name="bb" placeholder="Masukan Berat Badan Anda" type="number" class="form-control" required="required">
    </div>
    </div>
</div>
<div class="form-group row">
    <label for="text2" class="col-4 col-form-label">Tinggi Badan</label> 
    <div class="col-8">
    <div class="input-group">
        <div class="input-group-prepend">
        <div class="input-group-text">
            <i class="fa fa-adjust"></i>
        </div>
        </div> 
        <input id="tb" name="tb" placeholder="Masukan Tinggi Badan Anda" type="number" class="form-control" required="required">
    </div>
    </div>
</div>
<div class="form-group row">
    <div class="offset-4 col-8">
    <button name="submit" type="submit" class="btn btn-success">Submit</button>
    </div>
</div>
</form>
</div>

<?php
include_once 'bmi_pasien.php';
$tgl_periksa = $_POST['tgl_periksa'];
$nama = $_POST['nama'];
$gender = $_POST['gender'];
$berat = $_POST['bb'];
$tinggi = $_POST['tb'];
?>

<table class="table table-striped">
    <thead>
        <tr class="text-center">
            <th>No</th>
            <th>Nama</th>
            <th>Gender</th>
            <th>Tanggal Periksa</th>
            <th>Kode Pasien</th>
            <th>Berat</th>
            <th>Tinggi</th>
            <th>Nilai</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $psn1 = new BMIPasien('2022-01-12','Sinta','Wanita',56,170);
        $psn2 = new BMIPasien('2022-02-20','Harry','Pria',67,187);
        $psn3 = new BMIPasien('2022-04-02','Vira','Wanita',45,154);
        $ar_pasien = [$psn1,$psn2,$psn3];
        if ($_SERVER["REQUEST_METHOD"] == "POST"){
            if(empty($_POST["submit"])){
                $psn4 = new BMIPasien($tgl_periksa,$nama,$gender,$berat,$tinggi);
                array_push($ar_pasien,$psn4);
            }
        }

        $no = 1;
        foreach($ar_pasien as $pasien){
            echo '<tr class="text-center"><td>'.$no.'</td>';
            echo '<td>'.$pasien->nama.'</td>';
            echo '<td>'.$pasien->gender.'</td>';
            echo '<td>'.$pasien->tanggal.'</td>';
            echo '<td>'."P00".$no.'</td>';
            echo '<td>'.$pasien->berat.'</td>';
            echo '<td>'.$pasien->tinggi.'</td>';
            echo '<td>'.$pasien->nilai().'</td>';
            echo '<td>'.$pasien->status().'</td>';
            echo '</tr>';
            $no++;
        }
        ?>
    </tbody>
</table>
</div>

<?php
    include_once 'bawah.php'
?>