<?php
require "class_pasien.php";
require "class_bmi.php";

class BMIPasien extends BMI{
    public $tanggal;

    public function __construct($tgl_periksa,$nama,$gender,$berat,$tinggi){
        parent :: __construct($berat,$tinggi);
        $this->tanggal = $tgl_periksa;
        $this->nama = $nama;
        $this->gender = $gender;

    }

}
